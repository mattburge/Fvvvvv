import React, { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

const DEFAULT_HANDLE_STYLE = {
  width: 5,
  height: 5,
  bottom: -11,
  // background: '#ccc',
};

export default memo(({ data, isConnectable }) => {
  return (
    <>
      <div style={{ position: 'relative',  width: 10, height: 10, borderRadius: '25px'}} >
        <Handle
          type="target"
          id="toolH"
          position={Position.Top}
          style={{ ...DEFAULT_HANDLE_STYLE, left: '15%' }}
          onConnect={(params) => console.log('handle onConnect', params)}
          isConnectable={isConnectable}

        />
      </div>
    </>
  );
});
