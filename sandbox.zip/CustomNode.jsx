import React, { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

const DEFAULT_HANDLE_STYLE = {
  width: 5,
  height: 5,
  bottom: -11,
  // background: '#ccc',
};

export default memo(({ data, isConnectable }) => {
  return (
    <>
      <div style={{ position: 'relative', padding: 25}} >
        <div>Node</div>
        <div style={{color: '#ccc', position: 'absolute', bottom: -5, fontWeight: 'bold', fontSize: 6, left: 3}}>Model</div>
        <Handle
          type="source"
          id="red"
          position={Position.Bottom}
          style={{ ...DEFAULT_HANDLE_STYLE, left: '15%' }}
          onConnect={(params) => console.log('handle onConnect', params)}
          isConnectable={isConnectable}
        />
        <div style={{color: '#ccc', position: 'absolute', bottom: -5, fontSize: 6, fontWeight: 'bold', left: '40%'}}>Tools</div>
        <Handle
          type="source"
          position={Position.Bottom}
          id="ccc"
          style={{ ...DEFAULT_HANDLE_STYLE, left: '50%'}}
          isConnectable={isConnectable}
        />
        <div style={{color: '#ccc', position: 'absolute', bottom: -5, fontSize: 6, fontWeight: 'bold', left: '65%', right: -6}}>Output</div>
        <Handle
          type="source"
          position={Position.Bottom}
          id="orange"
          style={{ ...DEFAULT_HANDLE_STYLE, left: '85%' }}
          isConnectable={isConnectable}
        />
      </div>
    </>
  );
});
