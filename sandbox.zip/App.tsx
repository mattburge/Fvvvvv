import React, { useCallback } from 'react';
import {
  ReactFlow,
  useNodesState,
  useEdgesState,
  addEdge,
  Background,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';


import CustomNode from './CustomNode';
import ToolNode from './ToolNode';
import ConnectionLine from './ConnectionLine';

const initialNodes = [
  {
    id: 'connectionline-1',
    type: 'custom',
    data: { label: 'Node 1' },
    position: { x: 250, y: 5 },
  },
  {
    id: 'connectionline-2',
    type: 'tool',
    data: { label: 'Node 2' },
    position: { x: 250, y: 50 },
  },
];

const nodeTypes = {
  custom: CustomNode,
  tool: ToolNode,
};

const ConnectionLineFlow = () => {
  const [nodes, _, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  console.log(edges);
  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [],
  );

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      connectionLineComponent={ConnectionLine}
      onConnect={onConnect}
      fitView
      fitViewOptions={{
        padding: 0.2,
      }}
      style={{ backgroundColor: "#F7F9FB" }}
      >
        <Background />
      </ReactFlow>
  
  
  );
};

export default ConnectionLineFlow;
